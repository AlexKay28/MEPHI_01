from pytest import approx
from functools import reduce
from operator import add
from shadow.polyedr import Segment
